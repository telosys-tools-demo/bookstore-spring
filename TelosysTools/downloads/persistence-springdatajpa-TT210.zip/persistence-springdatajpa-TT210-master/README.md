persistence-springdatajpa
=========================

Telosys - Couche de persistence - Spring Data JPA
